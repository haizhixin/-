$(function() {
  $('body').html('<div>123</div>');
});
