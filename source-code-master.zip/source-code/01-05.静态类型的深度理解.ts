interface Point {
  x: number;
  y: number;
}

const point: Point = {
  x: 3,
  y: 4
};
