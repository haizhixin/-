### 课程使用的 secret 值为 secretKey
