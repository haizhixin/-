const teacher: string = 'dell';
console.log(teacher);
