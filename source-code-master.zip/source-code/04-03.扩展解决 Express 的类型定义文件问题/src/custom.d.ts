declare namespace Express {
  interface Request {
    teacherName: string;
  }
}
