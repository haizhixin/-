import React from 'react';

const App: React.FC = () => {
  return <div>hello world!</div>;
};

export default App;
