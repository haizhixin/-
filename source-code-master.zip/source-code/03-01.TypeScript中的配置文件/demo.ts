const teacher: string = null;
