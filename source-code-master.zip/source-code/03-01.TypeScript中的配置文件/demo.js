var teacher = null;
