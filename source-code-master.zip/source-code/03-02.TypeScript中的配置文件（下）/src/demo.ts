const teacher: string = null;

function fn(name: string, age: number) {
  console.log(age);
}

export const name = 'dell';
