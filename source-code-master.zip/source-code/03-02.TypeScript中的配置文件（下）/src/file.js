const a = '';
console.log(a.b.c);

export const name = 'dell';
