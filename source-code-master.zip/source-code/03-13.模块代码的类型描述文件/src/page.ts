import $ from 'jquery';

$(function() {
  $('body').html('<div>123</div>');
  new $.fn.init();
});
