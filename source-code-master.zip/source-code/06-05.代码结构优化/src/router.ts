import { Router } from 'express';

export default Router();
