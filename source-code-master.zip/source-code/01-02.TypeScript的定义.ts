// 静态类型
let b: number = 123;
b = 456;